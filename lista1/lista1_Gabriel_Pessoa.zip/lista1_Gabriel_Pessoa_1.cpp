//esccrever seu nome completo e os números entre 0 e a sua idade
#include <iostream>
int main(){
	std::cout << "Gabriel Gomes Pessôa \n";
	int c=1; // C esta inicializando em 1 pois queremos os numeros ENTRE 0 e a idade
	while(c<20){ //hoje é 04/07, a data de entrega é 11/07, meu aniversário é 08/07, então já to colocando 20 aninhos
		if(c<19){
			std::cout << c << ", ";
			c++;
		}
		else{
			std::cout << c << "\n";
			c++;
		}
	}
return 0;
}
